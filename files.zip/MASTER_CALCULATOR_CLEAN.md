# Master Calculator — cleaned & organized (work-in-progress)

This is a cleaned, organized version of the "MASTER CALCULATOR (1).txt" content you provided. I extracted the main sections, converted tables into structured lists, and flagged unclear values for you to confirm.

---

## 1) Document purpose / quick summary
- Primary goal: calculate required solar panels / inverter sizing and estimate system pricing based on monthly consumption (GDMTH rate) and demand.
- Inputs used: monthly kWh (12 months), monthly max demand (kW), factor de potencia, panel inventory, panel models/specs, pricing tiers by panel watt-range and inverter sizing.

---

## 2) Monthly consumption & demand (source: file)
- Annual total kWh (sum): 3,272,875 kWh
- Monthly kWh (as listed):
  - ENERO: 209,866
  - FEBRERO: 199,335
  - MARZO: 220,593
  - ABRIL: 273,707
  - MAYO: 192,804
  - JUNIO: 259,448
  - JULIO: 353,016
  - AGOSTO: 279,241
  - SEPTIEMBRE: 391,735
  - OCTUBRE: 357,998
  - NOVIEMBRE: 154,814
  - DICIEMBRE: 380,318

- Monthly max demand kW (as listed):
  - ENERO: 605
  - FEBRERO: 611
  - MARZO: 658
  - ABRIL: 776
  - MAYO: 606
  - JUNIO: 776
  - JULIO: 951
  - AGOSTO: 994
  - SEPTIEMBRE: 1078
  - OCTUBRE: 1043
  - NOVIEMBRE: 1015
  - DICIEMBRE: 1014

- Totals / key metrics (as listed)
  - Energía Total Anual (kWh): 3,272,875
  - Demanda Máxima del Año (kW): 1078
  - Demanda Máxima Promedio (kW): 844 (document shows "844")
  - Factor de Potencia (último mes): (value present but not cleanly parsed — please confirm)
  - Demanda anual (kW): (unclear — please confirm)

---

## 3) Inventory — panels & models (extracted)
I list all panel model references I found. Some quantities and details are unclear or scattered; I left placeholders where the original file had errors or ambiguous numbers.

- EFV010 — PANEL AMERISOLAR 330W (USADOS)
  - stock: 43 (value present near the AMERISOLAR row — please confirm)
- EFV031 — PANEL JINKO 470W
  - stock: (ambiguous in source; confirm)
- EFV041 — PANEL JINKO 555W
- EFV046 — PANEL JINKO 560W
- EFV042 — PANEL JINKO 585W
- EFV055 — PANEL JINKO 590W
- EFV057 — PANEL JINKO 615W
- EFV056 — PANEL JINKO 620W
- EFV048 — PANEL LUXEN 330W
- EFV054 — PANEL LUXEN 555W
- EFV044 — PANEL LUXEN 580W
- EFV049 — PANEL LUXEN 585W

Notes:
- The file contains many repeated tables with counts and calculated KWP per count (see pricing/quantity tables below). I kept model list separate to avoid mixing with pricing tiers.
- Several entries include "STOCK" numbers that are fragmented; I flagged those for confirmation.

---

## 4) Pricing / package table (summary)
The document contains large pricing tables split by panel watt-class (e.g., 550–560W, 580–590W, 620W). Key observations:

- Panel groups: 550–560W, 580–590W, 620W (tables for each group show:
  - CANT. PANELES (from 4 up to 100+)
  - KWP (system kW produced by that many panels)
  - PRECIO CONTADO (appears as per-panel or per-unit package price; values shown e.g. $10,900.00, $11,700.00, $12,400.00 etc.)
  - BIFASICO / TRIFASICO inverter sizing and surcharge (columns show recommended inverter combos and price increases per additional inverter: $2,500.00, $4,000.00, $12,500.00, $25,000.00 etc.)
- The price numbers appear to be in MXN. Please confirm currency.

Recommendation: convert each watt-range table into a CSV with columns:
- panel_watt_range, count_panels, kwp, price_contado, bifasico_recommendation, trifasico_recommendation, surcharge_next_inverter

I can build that CSV once you confirm ambiguous rows and currency.

---

## 5) Inverter sizing notes (from table)
- For each count, the document suggests inverter configurations (e.g. "6 KW + 5 KW", "10 KW + 10 KW + 5 KW", etc.) and indicates surcharges for upgrading inverter or going to tri-phase.
- There are repeated surcharge values across table rows: typical surcharges are $2,500; $4,000; $7,500; $12,500; $22,000; $25,000 and others. Please confirm exact mapping rules (when to add which surcharge).

---

## 6) Errors & missing values found
- Several cells in the original file show "#ERROR!" — these must be corrected (prices, KWP totals, inverter sizes).
- Some panel stock counts are ambiguous or bundled with other numbers (e.g., "2 413" near JINKO 470W). Please confirm.
- Factor de potencia (%) and other electrical factors are present but not consistently recorded per month.

---

## 7) Next steps I recommend (short)
1. Confirm currency (MXN?) and units for prices.
2. Provide any missing stock numbers and correct the "#ERROR!" cells.
3. Decide on output format you want: CSV (for programmatic use), JSON (for API), or cleaned Markdown/Excel (for human review).
4. If you want, I can:
   - Convert the panel inventory into a JSON file.
   - Convert the pricing tables into structured CSV files.
   - Produce a list of all images required (one per panel model + one per inverter configuration + photos for receipts) so you can gather images.

---

If you confirm the missing pieces (currency and whether you want CSV/JSON), I will output the cleaned files and convert the pricing tables into structured data automatically.