# Python script to produce quick visualizations from the CSV files provided above.
# Run: python3 solar_viz.py
import csv
import math
import matplotlib.pyplot as plt
import pandas as pd

# --------- config (edit if needed) -------------
PSH = 4.5   # peak sun hours from sheet
DERATE = 0.8
# ------------------------------------------------

def read_monthly(filename='inventory_monthly.csv'):
    df = pd.read_csv(filename)
    # Keep months in order as provided
    if 'TOTAL' in df['month'].values:
        df = df[df['month'] != 'TOTAL']
    return df

def read_catalog(filename='catalog.csv'):
    return pd.read_csv(filename)

def plot_monthly(df):
    months = df['month']
    kwh = df['kWh_total']
    demand = df['peak_demand_kW']

    fig, ax1 = plt.subplots(figsize=(12,6))
    ax1.bar(months, kwh, color='tab:skyblue', label='kWh total (month)')
    ax1.set_ylabel('kWh', color='tab:blue')
    ax1.tick_params(axis='y', labelcolor='tab:blue')
    ax1.set_xticklabels(months, rotation=45, ha='right')

    ax2 = ax1.twinx()
    ax2.plot(months, demand, color='tab:red', marker='o', label='Peak demand kW')
    ax2.set_ylabel('kW (peak demand)', color='tab:red')
    ax2.tick_params(axis='y', labelcolor='tab:red')

    plt.title('Monthly energy consumption and peak demand')
    fig.tight_layout()
    plt.savefig('monthly_consumption_demand.png', dpi=150)
    print('Saved monthly_consumption_demand.png')

def plot_catalog_pie(df):
    # group by brand -> stock
    df['stock'] = pd.to_numeric(df['stock'], errors='coerce').fillna(0)
    bybrand = df.groupby('brand')['stock'].sum()
    fig, ax = plt.subplots(figsize=(6,6))
    bybrand.plot.pie(ax=ax, autopct='%1.1f%%', startangle=90)
    plt.ylabel('')
    plt.title('Inventory distribution by brand (items count)')
    plt.savefig('catalog_inventory_pie.png', dpi=150)
    print('Saved catalog_inventory_pie.png')

def system_summary(df_monthly):
    annual = df_monthly['kWh_total'].sum()
    peak = df_monthly['peak_demand_kW'].max()
    per_kWp_year = PSH * 365.0
    required_kWp = annual / per_kWp_year
    adjusted_kWp = required_kWp / DERATE
    summary = {
        'annual_kWh': annual,
        'peak_kW': peak,
        'per_kWp_year': per_kWp_year,
        'required_kWp_no_losses': required_kWp,
        'required_kWp_with_losses': adjusted_kWp
    }
    return summary

def plot_system_summary(summary):
    fig, ax = plt.subplots(figsize=(8,4))
    labels = ['Peak (kW)', 'Required PV (kWp, adj)']
    vals = [summary['peak_kW'], summary['required_kWp_with_losses']]
    ax.bar(labels, vals, color=['tab:red','tab:green'])
    for i,v in enumerate(vals):
        ax.text(i, v*1.01, f"{v:,.0f}", ha='center')
    plt.title('Comparison: site peak vs required PV capacity (adjusted)')
    plt.savefig('system_summary_compare.png', dpi=150)
    print('Saved system_summary_compare.png')

def main():
    try:
        df_monthly = read_monthly('inventory_monthly.csv')
        df_catalog = read_catalog('catalog.csv')
    except Exception as e:
        print('Error reading CSVs:', e)
        return

    plot_monthly(df_monthly)
    plot_catalog_pie(df_catalog)
    summary = system_summary(df_monthly)
    print('\nSystem sizing quick summary:')
    for k,v in summary.items():
        if isinstance(v, float):
            print(f' - {k}: {v:,.2f}')
        else:
            print(f' - {k}: {v}')
    plot_system_summary(summary)

if __name__ == '__main__':
    main()