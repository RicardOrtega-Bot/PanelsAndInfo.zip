# Master Calculator — parsed summary

Source: provided "MASTER CALCULATOR (1).txt" and the attached screenshot.

Key KPIs
- Energía Total Anual (kWh): 3,272,875 kWh
- Demanda Máxima del Año (kW): 1,078 kW
- Demanda Máxima Promedio (kW): 844 kW (value found in text)
- Factor de Potencia (último mes): (value present in file; please confirm month if required)
- Demanda Maxima Promedio Anual: 844 (duplicate of above)

Monthly (kWh / peak kW)
- See `monthly_usage.csv` (ENERO → DICIEMBRE)

Tariff / kWh breakdown (from screenshot footer)
- kWh base: 10,207
- kWh intermedia: 23,115
- kWh punta: 1,831
- (Adjacent columns show decimals that appear to be distribution of percent or price factors: 0.29, 0.66, 0.05 — please confirm meaning)

Inventory / panels
- See `catalog.csv` — this is a best-effort extraction of every "EFVxxx" SKU and brand/model lines found.
- Numerous EFV lines and a large kit/inverter price table exist in the source; I captured SKUs and model names but many stock numbers and price fields are ambiguous in plain-text extraction.

Pricing / kits
- The file includes large tables mapping "number of panels" → "KWP" → "PRECIO CONTADO" → "BIFASICO / TRIFASICO" inverter upgrade costs.
- I recommend we parse that into a `kits.csv` if you want exact per-kit pricing and inverter options exported.

Open questions / actions
1. GDMTH tariff details: you mentioned you have a picture or a txt doc — please send the GDMTH tariff file or confirm if I should use the values extracted above (kWh base/intermedia/punta) as the tariff volumes and use standard sample prices. If the tariff includes demand charges and pf penalties, I will need the per-unit prices for:
   - energy base / intermedia / punta (MXN/kWh)
   - demand charges (MXN/kW)
   - kVArh / pf penalty rates
2. Catalog cleanup: do you want me to:
   - (A) produce a cleaned CSV with exact stock numbers + wattages (I will need the original sheet or confirm ambiguous lines)
   - (B) create a JSON catalog for the web app (brand/model/watt/stock/thumbnail_url)
3. Pricing kit table extraction: confirm if you want the full kits table parsed into rows (I can do that next).

What's next (suggested)
- You send the GDMTH tariff details (text or a clear image of the tariff lines). I will:
  - parse the tariff into numeric rates,
  - incorporate the kWh buckets and demand billing into the Master Calculator model,
  - produce a sample solar sizing result using the monthly usage.
- Confirm whether I should convert the `catalog.csv` into JSON and add a column for `image_filename` (so you can collect images and name them to match SKUs).
- If you prefer, I can also prepare a PR for 9ekaitz/PBL5-Solaris that:
  - adds `data/catalog.csv` and `data/monthly_usage.csv`,
  - and a small parser JS utility to load and show the catalog items.

Short repo analysis (quick)
- You asked to "analyze this similar repo project" — I saw:
  - 9ekaitz/PBL5-Solaris — description: "Solar panel e-commerce and management software" (languages: Java, HTML, CSS, SCSS, JS). Good candidate to host:
    - a catalog JSON/CSV for panel inventory and images,
    - the Master Calculator as a backend service or a client-side calculator module.
  - 9ekaitz/PBL5-Solaris-data-gen — mostly Jupyter Notebooks (data gen) — could be useful to produce solar yield/time-series samples and to seed the site with example production profiles.

If you want, I can:
- produce the JSON catalog file and a small preview page (HTML/JS) that loads it and shows thumbnails (placeholders),
- or parse the long kit/inverter price tables into "kits.csv".

Tell me which of these next steps you want me to do and whether you can upload:
- the GDMTH tariff text file (or clear photo),
- the original spreadsheet (Excel/CSV) for the Master Calculator,
- any missing inventory confirmation (stock numbers/prices).