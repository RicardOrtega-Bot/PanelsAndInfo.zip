# Master Calculator — summary and extraction plan

## 1. Raw inputs present
- Monthly kWh: 12 months (values present).
- Monthly maximum demand (kW): 12 months (values present).
- Annual aggregations: Energy Total Annual = 3,272,875 kWh (from file), Demanda Máxima Año = 1078 kW, Demanda Máxima Promedio (kW) = 844 (from text).
- Factor de potencia (Power Factor) present (last month).
- Inventory & panel models (see `catalog.csv` skeleton).
- Pricing tables mapping panel quantity → kWp → cash price → inverter sizes.

## 2. Core calculations to implement:
- AnnualEnergy = sum(monthly kWh)
- PeakDemand_kW = max(monthly demand kW)
- AvgDemand_kW = average(monthly demand kW)
- Required_kWp_solar = (AnnualEnergy / (PSH * system_efficiency * 365?)) OR by offset percent approach.
  - Clarify formula: If you assume PSH daily average (h/day), then:
    Required_kWp = (AnnualEnergy / 365) / (PSH * system_efficiency)
- Panel selection: choose combinations of panel models whose sum(Watt * count) >= Required_kWp*1000
- Inverter sizing: map panel kWp to inverter combos per table, add price deltas for bifasico/trifasico.
- Financials: calculate system cash price using panel unit price * qty + inverter price + discounts.

## 3. Missing / cleanup tasks
- Resolve #ERROR! cells.
- Extract numeric values for per-panel prices (many missing).
- Verify PSH value and efficiency factor (sheet shows PSH=4.5, eff=0.8 in rows — confirm).
- Normalize SKU names for image matching (exact model text).

## 4. Export artifacts needed for the agent
- catalog.csv (normalized)
- pricing_tables.csv (mapping of n_panels → kWp → price → inverter combo)
- monthly_consumption.csv (month, kWh, demand_kW)
- master_calculator_spec.md (this doc + calculation formulas)
- jinko_warranty.pdf (original PDF attached)

## 5. Suggested automated parsing script
- `scripts/parse_master_calculator.py` will:
  1. Read the raw TXT.
  2. Regex-extract panel tables, product rows and price tables.
  3. Output `catalog.csv`, `pricing_tables.csv`, `monthly_consumption.csv`.
  4. Mark rows with ambiguous data for manual review.