```markdown
# Solar catalog + PV simulation (starter)

What I included:
- panels_catalog_sample.csv — representative sample CSV extracted from your text capture.
- extract_tables.py — a lightweight extractor to run against a plain-text capture you provided.
- simulation.py — pvlib-based hourly PV generation + self-consumption calculator.
- app.py — a simple Plotly Dash app to visualize hourly / monthly results and catalog.
- requirements.txt — Python libs to install.

Recommended workflow:
1. Provide full text capture or original spreadsheet. If you want me to parse the entire captured sheet, say "Please parse the full text" and attach the full text file or spreadsheet.
2. Provide location (lat/lon and timezone) and load profile (hourly CSV) or say "use typical residential/commercial profile".
3. Provide tariff structure or let me use a sample tariff.
4. I will run the extractor on the full text and produce:
   - panels_catalog.csv (full)
   - simulation_hourly.csv and simulation_monthly.csv for a configured system (you can test multiple sizes)
   - a generated PDF report (if requested) with charts and tables and a ready-to-run Dash app.

Notes:
- The extractor is heuristic-based for text captures. If you have the original spreadsheet (XLSX/CSV) it is much simpler and more accurate to use that.
- The simulation uses pvlib's PVWatts-like entry for quick estimates. If you want a more detailed module-level model (Sandia or CEC), provide module electrical params or module name and I can fetch from pvlib's database.
- For GDMTH-specific billing (demand charges, time-of-use tiers and maxima), please provide the exact tariff rules (monthly demand charge calculation, peak hours definitions, kWh tier prices). I can implement them in the monthly_bill function.

Next steps — tell me:
- Confirm you want me to parse the entire captured text (attach it) OR upload the original spreadsheet.
- Provide lat/lon or city, timezone.
- Provide hourly load CSV or allow me to use a synthetic profile and indicate residential or commercial.
- Provide tariff parameters or confirm example values are fine.

Once you confirm, I will:
- run the full extraction,
- run the pvlib simulation with your inputs,
- produce a downloadable CSV, charts, and a PDF report; or push a complete Dash app folder you can run locally.
```