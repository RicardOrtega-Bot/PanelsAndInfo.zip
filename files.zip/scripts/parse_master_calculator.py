#!/usr/bin/env python3
"""
Parse MASTER CALCULATOR (raw txt) into structured CSVs:
 - catalog.csv
 - monthly_consumption.csv
 - pricing_tables.csv

This is a starter script: it should be expanded to capture all table formats.
"""
import re
import csv
from pathlib import Path

RAW = Path("MASTER CALCULATOR (1).txt").read_text(encoding="utf-8", errors="ignore")

# Example: extract monthly table using a regex approach.
# (Implement robust parsing for the actual formatting.)
def extract_monthly(raw):
    # naive approach: find known month rows and the two columns
    months = ["ENERO","FEBRERO","MARZO","ABRIL","MAYO","JUNIO","JULIO","AGOSTO","SEPTIEMBRE","OCTUBRE","NOVIEMBRE","DICIEMBRE"]
    lines = raw.splitlines()
    rows=[]
    for i,line in enumerate(lines):
        for m in months:
            if line.strip().startswith(m):
                # attempt to capture numbers on subsequent lines
                # This will need refinement for the actual layout
                try:
                    kwh = re.search(r'(\d{5,7})', lines[i+1]).group(1)
                    kwp = re.search(r'(\d{2,4})', lines[i+2]).group(1)
                except Exception:
                    kwh, kwp = "", ""
                rows.append((m,kwh,kwp))
    return rows

if __name__ == "__main__":
    monthly = extract_monthly(RAW)
    with open("monthly_consumption.csv","w",newline="") as f:
        writer=csv.writer(f)
        writer.writerow(["month","kWh_total","peak_demand_kw"])
        for m,kwh,kw in monthly:
            writer.writerow([m,kwh,kw])
    print("Wrote monthly_consumption.csv (partial).")