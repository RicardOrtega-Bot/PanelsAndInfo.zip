# System summary (from MASTER CALCULATOR data)

Source numbers used:
- Annual energy (kWh): 3,272,875 kWh
- Peak measured KWMax (monthly max read): 1,078 kW (from sheet)
- Average monthly peak reported in sheet: 844 kW (reference)
- PSH (peak sun hours): 4.5 (appears in the panel table)
- Panel derate/efficiency factor used: 0.8 (from sheet values)

Sizing estimate (quick):
- Annual production per kWp (approx) = PSH * 365 = 4.5 * 365 = 1,642.5 kWh per kWp-year
- Required PV DC capacity to cover 100% of annual energy:
  required_kWp = annual_kWh / (PSH * 365) = 3,272,875 / 1,642.5 ≈ 1,993 kWp (≈ 1.993 MWp)
- If you include system losses / derate (0.8), increase DC by 1/0.8:
  adjusted_kWp = 1,993 / 0.8 ≈ 2,491 kWp (≈ 2.49 MWp)
- Compare to building peak: KWMax = 1,078 kW. A PV peak ~2.49 MWp would be DC/AC ratio ~2.3 if AC size is sized to peak demand (2.49 / 1.078 ≈ 2.31). That’s a high DC/AC but common for self-consumption heavy sites.

Notes & assumptions:
- PSH = 4.5 used uniformly (use local PSH map to refine).
- Losses include inverter, soiling, temperature, mismatch (we used sheet 0.8 as overall derate).
- This is a first-pass estimate to visualize scale. Final design needs hourly load profile, export limits, and tariff considerations.

What the Python script will produce:
- Monthly consumption bar chart (kWh) and overlaid monthly peak demand (kW).
- Pie chart of catalog inventory by model (from catalog.csv).
- A short summary PNG with the annual energy / required kWp and comparison to KWMax.

Next steps:
- If you want an hourly simulation or to match PV generation to load to compute self-consumption and grid exports, I can prepare a short notebook using PVLIB and your hourly profile (if available).
- I can also extract all pricing table rows into a larger table if you want full quantity-to-price mapping (the sheet has many rows; I captured representative entries).