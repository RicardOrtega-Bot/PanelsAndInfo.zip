# Catalog items extracted (initial catalog list)

Below is an extracted catalog of items and categories from the material you provided. This is intended as a starting list to gather images and confirm details.

## Panel models (raw references)
- AMERISOLAR 330W — model EFV010 (used)
- JINKO 470W — model EFV031
- JINKO 555W — model EFV041
- JINKO 560W — model EFV046
- JINKO 585W — model EFV042
- JINKO 590W — model EFV055
- JINKO 615W — model EFV057
- JINKO 620W — model EFV056
- LUXEN 330W — model EFV048
- LUXEN 555W — model EFV054
- LUXEN 580W — model EFV044
- LUXEN 585W — model EFV049

(There may be duplicates/variants in the source; confirm final SKUs.)

## Accessories / system items referenced
- Inverter packages and combos (bifásico / trifásico) — multiple recommended combos (2 kW, 3 kW, 5 kW, 6 kW, 10 kW, 15 kW, 20 kW, 25 kW, 30 kW, 36 kW, 50 kW, 60 kW).
- Surcharges for additional inverter upgrades / tri-phase conversion.
- "RECIBO" / billing pages — images of receipts for data extraction.
- Notes / "Model (Kwh)" — possibly templates or per-site energy production models.

## Suggested image list to gather
For a product catalog UI and for proposals, gather images for:
- Each panel model (front photo, datasheet image)
- Each inverter model used in recommended combos
- Example completed systems (roof / ground mount)
- Receipt sample images (first & second page)
- Warranty/datasheet images (e.g., Jinko warranty PDF)
- Logos for brands (Jinko, Amerisolar, Luxen)

## Prioritization suggestions
1. Panel model images (one set per SKU)
2. Datasheets / spec graphics
3. Inverter model images
4. Receipt & contract templates (for the calculator)
5. Brand logos

If you want, I can produce a CSV with one row per SKU including fields:
- sku, brand, wattage, model_code, stock (if provided), preferred_image_filename, notes

Tell me which fields you'd like and I will produce the CSV.